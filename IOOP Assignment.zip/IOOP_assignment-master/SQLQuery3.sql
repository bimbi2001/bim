﻿CREATE TABLE Comment(
Coach_Refno VARCHAR(15),
Member_Refno VARCHAR(15),
Comment VARCHAR(300)
);