﻿CREATE TABLE Comment(
Coach_RefNo VARCHAR(10),
Member_RefNo VARCHAR(10),
Comment VARCHAR(300)

);