package classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Utility {

    
    public static void writeFile(List<List<String>> records, String fileName, boolean append) {
        // Try-with-resources to automatically close the BufferedWriter
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, append))) {
            // Iterate through each record in the list of records
            for (List<String> record : records) {
                // Join the strings in each record with ", " and write to the file
                writer.write(String.join(", ", record));
                // Write a new line after each record
                writer.newLine();
            }
        } catch (IOException e) {
            // Print the stack trace in case of an IOException (e.g., file access issues)
            e.printStackTrace();
        }
    }

    public static List<List<String>> readFileWithHeaders(String fileName) {
        // Initialize a list to hold the contents of the file
        List<List<String>> contents = new ArrayList<>();
        // Try-with-resources to automatically close the BufferedReader
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            // Read each line from the file until EOF is reached
            while ((line = reader.readLine()) != null) {
                // Split the line by ", " into an array of strings
                String[] record = line.split(", ");
                // Convert the array to a list and add it to the contents
                List<String> recordList = new ArrayList<>();
                for (String value : record) {
                    recordList.add(value);
                }
                // Add the parsed record to the list of contents
                contents.add(recordList);
            }
        } catch (IOException e) {
            // Print the stack trace in case of an IOException (e.g., file access issues)
            e.printStackTrace();
        }
        // Return the full contents of the file
        return contents;
    }

    public static List<List<String>> readFile(String fileName) {
        // Read the file including headers
        List<List<String>> fileDataWithHeaders = readFileWithHeaders(fileName);
        // Check if the file is empty to avoid IndexOutOfBoundsException
        if (fileDataWithHeaders.isEmpty()) {
            // Return an empty list if the file has no data
            return new ArrayList<>(); 
        }
        
        // Remove the first row (headers) and return the rest of the data
        List<List<String>> fileData = fileDataWithHeaders.subList(1, fileDataWithHeaders.size());
        return fileData;
    }
    
 
    
    
    public static String generateID(String fileName) {
        String prefix;
        switch (fileName) {
            case "src/txt_files/customer.txt":
                prefix = "C";
                break;
            case "src/txt_files/scheduler.txt":
                prefix = "S";
                break;
            case "src/txt_files/manager.txt":
                prefix = "M";
                break;
            case "src/txt_files/hall.txt":
                prefix ="H";
                break;
            case "src/txt_files/feedbacks.txt":
                prefix = "F";
                break;
            case "src/txt_files/bookings.txt":
                prefix ="B";
                break;
            default:
                prefix = "Unknown";
                break;
        }

        
        List<List<String>> userData = Utility.readFile(fileName);
        
        if (userData.isEmpty() || userData.get(0).isEmpty()) {
            return prefix + "/001/";
        }

        
        String lastIDStr = userData.get(userData.size() - 1).get(0);
        System.out.println(lastIDStr);
        int lastID = Integer.parseInt(lastIDStr.substring(2, 5));
        int newID = lastID + 1;

        
        return String.format("%s/%03d/", prefix, newID);
    }
}
