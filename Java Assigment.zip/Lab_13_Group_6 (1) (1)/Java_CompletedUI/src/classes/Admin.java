package classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;



public class Admin implements super_class{

    // Private fields for the Admin class
    private String username;
    private String admin_ID;
    private String admin_name;
    private String password;

    // Constructor to initialize all the fields
    public Admin(String username, String admin_ID, String admin_name, String password) {
        this.setUsername(username);
        this.setAdmin_ID(admin_ID);
        this.setAdmin_name(admin_name);
        this.setPassword(password);
    }
    
    public Admin(String admin_ID) {
        this.setAdmin_ID(admin_ID);
    }
    
    public Admin() {
    }

    // Getter and Setter for username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // Getter and Setter for admin_ID
    public String getAdmin_ID() {
        return admin_ID;
    }

    public void setAdmin_ID(String admin_ID) {
        this.admin_ID = admin_ID;
    }

    // Getter and Setter for admin_name
    public String getAdmin_name() {
        return admin_name;
    }

    public void setAdmin_name(String admin_name) {
        this.admin_name = admin_name;
    }

    // Getter and Setter for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public void viewCustomer(JTable view_cus){
        String customer_file = "src/txt_files/customer.txt";
    // Extract data from the file
    List<List<String>> userData = extractData(customer_file);
    // Get the table's model
    DefaultTableModel model = (DefaultTableModel) view_cus.getModel();
    // Clear existing rows in the table
    model.setRowCount(0);
    // Add each record from userData to the table model
    for (List<String> record : userData) {
        model.addRow(record.toArray());
    }
    }                                       
    public static List<List<String>> extractData(String fileName) {
        // Initialize a list to hold the extracted data
        List<List<String>> extractedData = new ArrayList<>();

        // Try-with-resources to automatically close the BufferedReader
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            // Read each line from the file until EOF is reached
            while ((line = reader.readLine()) != null) {
                // Split the line by a comma, followed by optional spaces
                String[] fields = line.split(",");
                // Initialize a list to hold the selected fields
                List<String> table_data = new ArrayList<>();
                // Extract specific fields by index
                table_data.add(fields[0]); 
                table_data.add(fields[2]);
                table_data.add(fields[1]); 
                table_data.add(fields[3]); 
                table_data.add(fields[4]);
                table_data.add(fields[5]);
                table_data.add(fields[6]); 
                table_data.add(fields[7]); 
                table_data.add(fields[9]); 

                // Add the extracted data to the list
                extractedData.add(table_data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Remove the first row (headers) and return the rest of the data if needed
        if (!extractedData.isEmpty()) {
            extractedData.remove(0); // Remove headers
        }

        return extractedData;
    }
    
    
   
    
    @Override
    public void showItems(JComboBox stuff_box,JTable view_stuff) {
    // Get the selected item from the combo box
    String selectedItem = (String) stuff_box.getSelectedItem();
    String manager_file = "src/txt_files/manager.txt";
    String scheduler_file = "src/txt_files/scheduler.txt";
    List<List<String>> managerData = extractData(manager_file);
    List<List<String>> schedulerData = extractData(scheduler_file);
    if (selectedItem.equals("(1) No filter")) {
        // Combine the data from both files
        List<List<String>> combinedData = new ArrayList<>();
        combinedData.addAll(managerData);
        combinedData.addAll(schedulerData);
        
        // Get the table's model
        DefaultTableModel model = (DefaultTableModel) view_stuff.getModel();
        
        // Clear existing rows in the table
        model.setRowCount(0);
        
        // Add each record from combinedData to the table model
        for (List<String> record : combinedData) {
            model.addRow(record.toArray());
        }
    } else if(selectedItem.equals("(2) By Manager")){
         List<List<String>> combinedData_1 = new ArrayList<>();
        combinedData_1.addAll(managerData);

        // Get the table's model
        DefaultTableModel model = (DefaultTableModel) view_stuff.getModel();
        
        // Clear existing rows in the table
        model.setRowCount(0);
        
        // Add each record from combinedData to the table model
        for (List<String> record : combinedData_1) {
            model.addRow(record.toArray());
            }
        } else if(selectedItem.equals("(3) By Scheduler")){
         List<List<String>> combinedData_2 = new ArrayList<>();
        combinedData_2.addAll(schedulerData);

        // Get the table's model
        DefaultTableModel model = (DefaultTableModel) view_stuff.getModel();
        
        // Clear existing rows in the table
        model.setRowCount(0);
        
        // Add each record from combinedData to the table model
        for (List<String> record : combinedData_2) {
            model.addRow(record.toArray());
            }
    }
    }
    
    public boolean updateStaff(String staffID, String filePath, String staffName, String nationalID, String birthDate, String phoneNumber, String email, String hallType, String username) {
    File file = new File(filePath);
    StringBuilder updatedContent = new StringBuilder();

    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
        String line;

        // Read the header line
        String header = reader.readLine();
        updatedContent.append(header).append(System.lineSeparator());

        while ((line = reader.readLine()) != null) {
            line = line.trim();
            String[] details = line.split("\\s*,\\s*");

            if (details.length < 8) {
                continue;  // Skip malformed lines
            }

            if (details[0].trim().equalsIgnoreCase(staffID)) {
                // Match found - overwrite the fields that can be updated
                details[1] = staffName;
                details[2] = nationalID;
                details[3] = birthDate;
                details[5] = phoneNumber;
                details[6] = email;
                details[9] = hallType;
                details[7] = username;  // Update the username
            }

            updatedContent.append(String.join(",", details)).append(System.lineSeparator());
        }
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }

    // Write the updated content back to the original file
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
        writer.write(updatedContent.toString());
    } catch (IOException e) {
        e.printStackTrace();
        return false;
    }

    return true;

    }                             
    
    public void delete_staff(String staff_id){
    String manager_file = "src/txt_files/manager.txt";
            String scheduler_file = "src/txt_files/scheduler.txt";

            // Read data from both files
            List<List<String>> manager_data = Utility.readFileWithHeaders(manager_file);
            List<List<String>> scheduler_data = Utility.readFileWithHeaders(scheduler_file);

            // Update the status in the manager file
            for (List<String> innerList : manager_data) {
                if (innerList.get(0).equals(staff_id)) {
                    int lastIndex = innerList.size() - 1;
                    System.out.println(innerList.get(lastIndex));
                    innerList.set(lastIndex, "Blocked");
                    Utility.writeFile(manager_data, manager_file, false);
                    break; // Exit the loop after updating the record
                }
            }

            // Update the status in the scheduler file
            for (List<String> innerList : scheduler_data) {
                if (innerList.get(0).equals(staff_id)) {
                    int lastIndex = innerList.size() - 1;
                    innerList.set(lastIndex, "Blocked");
                    Utility.writeFile(scheduler_data, scheduler_file, false);
                    break; // Exit the loop after updating the record
                }
            }
    }
    public void delete_Customers(String customer_id){
    String customerFile = "src/txt_files/customer.txt";
            List<List<String>> customer_data = Utility.readFileWithHeaders(customerFile);

            for (List<String> innerList : customer_data) {
                if (innerList.get(0).equals(customer_id)) {
                    customer_data.remove(innerList);

                    Utility.writeFile(customer_data, customerFile, false);
                    break; // Exit the loop after updating the record
                } 
            }
    }
    
    public boolean register_staff(String filePath, String staff_national_id, String phone_number, String staff_email, String staff_account){
        // Read data from the file and check credentials
    List<List<String>> userData = Utility.readFile(filePath);

    boolean isDuplicate = userData.stream().anyMatch(record ->     
    record.contains(staff_national_id) || 
    record.contains(phone_number) || 
    record.contains(staff_email) ||
    record.contains(staff_account)
    );
    return isDuplicate;
    }
    }

