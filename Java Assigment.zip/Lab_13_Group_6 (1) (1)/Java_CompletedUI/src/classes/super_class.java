/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package classes;

import javax.swing.JComboBox;
import javax.swing.JTable;

/**
 *
 * @author liewj
 */
public interface super_class {
    
    public void showItems(JComboBox stuff_box,JTable view_stuff);
    
}
