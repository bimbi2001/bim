package classes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Scheduler implements super_class{

    // Private fields for the Scheduler class
    private String username;
    private String scheduler_ID;
    private String scheduler_name;
    private String password;

    // Constructor to initialize all the fields
    public Scheduler(String username, String scheduler_ID, String scheduler_name, String password) {
        this.setUsername(username);
        this.setScheduler_ID(scheduler_ID);
        this.setScheduler_name(scheduler_name);
        this.setPassword(password);
    }
    
    public Scheduler(String scheduler_ID) {
        
        this.setScheduler_ID(scheduler_ID);
        
    }
    
      public Scheduler() {
    }

    // Getter and Setter for username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // Getter and Setter for scheduler_ID
    public String getScheduler_ID() {
        return scheduler_ID;
    }

    public void setScheduler_ID(String scheduler_ID) {
        this.scheduler_ID = scheduler_ID;
    }

    // Getter and Setter for scheduler_name
    public String getScheduler_name() {
        return scheduler_name;
    }

    public void setScheduler_name(String scheduler_name) {
        this.scheduler_name = scheduler_name;
    }

    // Getter and Setter for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    public void add_hall(JTextField txt_Hall_Name, JComboBox cb_Hall_Type, JTextField txt_Hall_Address, String HallType){
    // Get the selected index from the combo box
    int selectedIndex = cb_Hall_Type.getSelectedIndex();

    // Define variables for hall details
    String hallType;
    String hallIdPrefix;
    String hallName;
    
    // Define the file path
    String filePath = "src/txt_files/hall.txt";
    
    // Determine hall type and corresponding prefix based on selected index
    switch (selectedIndex) {
        case 0: // Auditorium
            hallType = "Auditorium";
            hallName = txt_Hall_Name.getText().trim();
            
            break;
        case 1: // Banquet Hall
            hallType = "Banquet Hall";
            hallName = txt_Hall_Name.getText().trim();
            break;
        case 2: // Meeting Room
            hallType = "Meeting Room";
            hallName = txt_Hall_Name.getText().trim();
            break;
        default:
        // Handle invalid index
        JOptionPane.showMessageDialog(null, "Invalid hall type selected.");
        return;
}

    // Generate the Hall_ID
    String hallId = Utility.generateID(filePath);
    System.out.println(hallId);
    
    // Get the Hall Name and Address from the text fields

    String hallAddress = txt_Hall_Address.getText().trim();

    // Check for any blank fields
    if (hallName.isEmpty() || hallAddress.isEmpty()) {
        // Show an error message if any field is blank
        JOptionPane.showMessageDialog(null, "Please fill in all the fields correctly.", "Input Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit the method to prevent writing incomplete data
}



    // Create a list of records
    List<List<String>> records = new ArrayList<>();

    // Add collected data to the records list
    records.add(Arrays.asList(hallId, hallType, hallName, hallAddress));

    // Write the data to the file
    Utility.writeFile(records, filePath, true);  // 'true' to append to the file

    //Show a confirmation message
    JOptionPane.showMessageDialog(null, "Hall information saved successfully!");
    }                                       
    

    //Show halls
    @Override
    public void showItems(JComboBox jComboBox2,JTable jTable1) {
    // Get the selected item from the combo box
    String selectedItem = (String) jComboBox2.getSelectedItem();
    
    List<List<String>> managerData = Utility.readFileWithHeaders("src/txt_files/hall.txt");
    if (selectedItem.equals("(1) None")) {
        // Combine the data from both files
        List<List<String>> combinedData = new ArrayList<>();
        combinedData.addAll(managerData);
       
        
        // Get the table's model
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        
        // Clear existing rows in the table
        model.setRowCount(0);
        
        // Add each record from combinedData to the table model
        for (List<String> record : combinedData) {
            
                model.addRow(record.toArray());
            
        }
    } else if(selectedItem.equals("(2) Auditorium")){
         List<List<String>> combinedData_1 = new ArrayList<>();
        combinedData_1.addAll(managerData);

        // Get the table's model
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        
        // Clear existing rows in the table
        model.setRowCount(0);
        
        // Add each record from combinedData to the table model
        for (List<String> record : combinedData_1) {
            if (record.get(1).equals("Auditorium")){
                model.addRow(record.toArray());
            }
            
            }
        } else if(selectedItem.equals("(3) Meeting Room")){
         List<List<String>> combinedData_1 = new ArrayList<>();
         combinedData_1.addAll(managerData);

        // Get the table's model
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        
        // Clear existing rows in the table
        model.setRowCount(0);
        
        // Add each record from combinedData to the table model
        for (List<String> record : combinedData_1) {
            if (record.get(1).equals("Meeting Room")){
                model.addRow(record.toArray());
            }
            
            }
    }else{
             List<List<String>> combinedData_1 = new ArrayList<>();
         combinedData_1.addAll(managerData);

        // Get the table's model
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        
        // Clear existing rows in the table
        model.setRowCount(0);
        
        // Add each record from combinedData to the table model
        for (List<String> record : combinedData_1) {
            if (record.get(1).equals("Banquet Hall")){
                model.addRow(record.toArray());
            }
            }
        }
    }
    
    public boolean delete_hall(List<String> lines, String hallToDelete) throws IOException{
        // File path
        String filePath = "src/txt_files/hall.txt";
        // Use a list to store the lines that should remain in the file
        List<String> updatedLines = new ArrayList<>();
        
        // Flag to check if a matching Hall ID is found
        boolean hallDeleted = false;
        
        // Iterate over each line to find the one to delete
        for (String line : lines) {
            // If the line does not start with the Hall ID, keep it
            if (!line.trim().startsWith(hallToDelete + ",")) {
                updatedLines.add(line);
            } else {
                // Hall ID matched, set flag to true
                hallDeleted = true;
            }
        }
        
        // Write the remaining lines back to the file
        Files.write(Paths.get(filePath), updatedLines, StandardOpenOption.TRUNCATE_EXISTING);
        
        
        return hallDeleted;
    }
    
    
}
