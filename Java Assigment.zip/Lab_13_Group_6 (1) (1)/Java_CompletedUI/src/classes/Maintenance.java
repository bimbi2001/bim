package classes;

import java.time.LocalDate;
import java.time.LocalTime;

public class Maintenance extends Schedule{

    private String maintenance_ID;
    private String status;

    public Maintenance(String maintenance_ID, String status, LocalDate date, LocalTime time) {

        // Call to the super class constructor to initialize the requisite fields from the schedule class
        super(null, null, null, date, time);
        this.setStatus(status);
        this.setMaintenanceID(maintenance_ID);
    }

    // Getter and Setter for status
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if (this.status.equalsIgnoreCase("Under Maintenance") ||
                this.status.equalsIgnoreCase("Fully Operational")) {

            this.status = status;

        } else {
            throw new IllegalArgumentException("Status must be either 'Under Maintenance' or 'Fully Operational'");
        }
    }
    
    public void setMaintenanceID(String maintenance_ID){
        this.maintenance_ID = maintenance_ID;
    }
    
    public String getMaintenanceID(){
        return this.maintenance_ID;
    }
   
}
